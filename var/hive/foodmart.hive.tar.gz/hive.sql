CREATE EXTERNAL TABLE store (
	store_id INT
	,store_type String
	,region_id INT
	,sales_region_id INT
	,store_name String
	,store_number INT
	,store_street_address String
	,store_city String
	,store_state String
	,store_postal_code String
	,store_country String
	,store_manager String
	,store_phone String
	,store_fax String
	,first_opened_date TIMESTAMP
	,last_remodel_date TIMESTAMP
	,store_sqft INT
	,grocery_sqft INT
	,frozen_sqft INT
	,meat_sqft INT
	,coffee_bar boolean
	,video_store boolean
	,salad_bar boolean
	,prepared_food boolean
	,florist boolean
	) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
 STORED AS TEXTFILE
 LOCATION '/user/hive/product_class';

CREATE EXTERNAL TABLE time_by_day (
  time_id INT ,
  the_date TIMESTAMP,
  the_day String,
  the_month String,
  the_year INT,
  day_of_month INT,
  week_of_year INT,
  month_of_year INT,
  quarter String,
  fiscal_period String
) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
 STORED AS TEXTFILE
 LOCATION '/user/hive/time_by_day';

CREATE EXTERNAL TABLE inventory_fact_1998 (
  product_id INT ,
  time_id INT ,
  warehouse_id INT ,
  store_id INT ,
  units_ordered INT,
  units_shipped INT,
  warehouse_sales decimal(10,4),
  warehouse_cost decimal(10,4),
  supply_time INT,
  store_invoice decimal(10,4)
) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
 STORED AS TEXTFILE
 LOCATION '/user/hive/inventory_fact_1998';


CREATE EXTERNAL TABLE product_class (
  product_class_id INT ,
  product_subcategory String,
  product_category String,
  product_department String,
  product_family String
)  ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
 STORED AS TEXTFILE
 LOCATION '/user/hive/product_class';

CREATE EXTERNAL TABLE product (
  product_class_id INT ,
  product_id INT ,
  brand_name String ,
  product_name String ,
  SKU bigint,
  SRP decimal(10,4) ,
  gross_weight double ,
  net_weight double ,
  recyclable_package boolean ,
  low_fat boolean ,
  units_per_case INT ,
  cases_per_pallet INT ,
  shelf_width double ,
  shelf_height double ,
  shelf_depth double 
 ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
 STORED AS TEXTFILE
 LOCATION '/user/hive/product';



